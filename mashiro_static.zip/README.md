# mashiro

> 在Sakura的基础上稍作了修改，暂时只写了PC端，移动端待定

> 预览地址：<a href="http://xm17906193.gitee.io/vue-sakura" target="_blank" style="color:LightPink">click here~</a>

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report

# run unit tests
npm run unit

# run e2e tests
npm run e2e

# run all tests
npm test
```

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
